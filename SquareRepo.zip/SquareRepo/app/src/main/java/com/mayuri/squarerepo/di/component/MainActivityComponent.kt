package com.mayuri.squarerepo.di.component

import android.content.Context

import com.mayuri.squarerepo.di.module.AdapterModule
import com.mayuri.squarerepo.di.qualifier.ActivityContext
import com.mayuri.squarerepo.di.scope.ActivityScope
import com.mayuri.squarerepo.di.scope.ApplicationScope
import com.mayuri.squarerepo.ui.MainActivity

import dagger.Component
import dagger.Provides
import dagger.Subcomponent
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
@Subcomponent(modules = [AdapterModule::class])
interface MainActivityComponent {

    @get:ActivityContext
    val context: Context


    fun injectMainActivity(mainActivity: MainActivity)
}
