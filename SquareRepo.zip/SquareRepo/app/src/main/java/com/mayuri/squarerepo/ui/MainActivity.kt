package com.mayuri.squarerepo.ui


import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter

import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.mayuri.squarerepo.MyApplication
import com.mayuri.squarerepo.R
import com.mayuri.squarerepo.adaptor.RecyclerViewAdapter
import com.mayuri.squarerepo.di.component.ApplicationComponent
import com.mayuri.squarerepo.di.component.DaggerMainActivityComponent
import com.mayuri.squarerepo.di.component.MainActivityComponent
import com.mayuri.squarerepo.di.module.MainActivityContextModule
import com.mayuri.squarerepo.di.qualifier.ActivityContext
import com.mayuri.squarerepo.di.qualifier.ApplicationContext
import com.mayuri.squarerepo.pojo.SquareRepo
import com.mayuri.squarerepo.retrofit.APIInterface
import dagger.Provides

import javax.inject.Inject

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity(), RecyclerViewAdapter.ClickListener {

    @set:Inject
    var recyclerView: RecyclerView? = null

    @set:Inject
    var mainActivityComponent: MainActivityComponent? = null

    @set:Inject
    var recyclerViewAdapter: RecyclerViewAdapter? = null

    @set:Inject
    var apiInterface: APIInterface? = null

    @set:Inject
    @ApplicationContext
    var mContext: Context? = null

    @set:Inject
    @ActivityContext
    var activityContext: Context? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerview)
        recyclerView!!.layoutManager = LinearLayoutManager(this@MainActivity)

     val applicationComponent = MyApplication[this].applicationComponent
        mainActivityComponent = DaggerMainActivityComponent.builder()
                .mainActivityContextModule(MainActivityContextModule(this))
                .applicationComponent(applicationComponent)
                .build()

        recyclerViewAdapter = RecyclerViewAdapter(this)
        recyclerView!!.adapter = recyclerViewAdapter

        apiInterface!!.squareRepo.enqueue(object : Callback<List<SquareRepo>> {
            override fun onResponse(call: Call<List<SquareRepo>>, response: Response<List<SquareRepo>>) {

                val squareRepoList = response.body()

                val squareRepos = arrayOfNulls<String>(squareRepoList!!.size)

                for (i in squareRepoList.indices) {
                    squareRepos[i] = squareRepoList[i].name
                }

                //displaying the string array into listview
                recyclerViewAdapter!!.setData(squareRepoList)
                recyclerViewAdapter!!.notifyDataSetChanged()

            }

            override fun onFailure(call: Call<List<SquareRepo>>, t: Throwable) {

            }

        })

    }

    override fun launchIntent(RepoName: String) {

    }
}

