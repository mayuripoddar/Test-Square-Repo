package com.mayuri.squarerepo.di.component

import android.content.Context


import com.mayuri.squarerepo.MyApplication
import com.mayuri.squarerepo.di.module.ContextModule
import com.mayuri.squarerepo.di.module.RetrofitModule
import com.mayuri.squarerepo.di.qualifier.ApplicationContext
import com.mayuri.squarerepo.di.scope.ApplicationScope
import com.mayuri.squarerepo.retrofit.APIInterface

import dagger.Component

@ApplicationScope
@Component(modules = [ContextModule::class, RetrofitModule::class])
interface ApplicationComponent {

    val apiInterface: APIInterface

    @get:ApplicationContext
    val context: Context

    fun injectApplication(myApplication: MyApplication)
}
