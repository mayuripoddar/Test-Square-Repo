package com.mayuri.squarerepo.di.module

import android.content.Context

import com.mayuri.squarerepo.di.qualifier.ApplicationContext
import com.mayuri.squarerepo.di.scope.ApplicationScope

import dagger.Module
import dagger.Provides


@Module
class ContextModule(private val context: Context) {

    @Provides
    @ApplicationScope
    @ApplicationContext
    fun provideContext(): Context {
        return context
    }
}
