package com.mayuri.squarerepo.adaptor


import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast

import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView


import com.bumptech.glide.Glide
import com.mayuri.squarerepo.R
import com.mayuri.squarerepo.pojo.SquareRepo

import java.util.ArrayList
import java.util.HashMap

import javax.inject.Inject

import androidx.core.content.ContextCompat.getColor
import com.mayuri.squarerepo.R.*
import com.mayuri.squarerepo.adaptor.RecyclerViewAdapter.ViewHolder
import com.squareup.picasso.Picasso


class RecyclerViewAdapter @Inject
constructor(clickListener: ClickListener) : RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>() {

    internal val data: MutableList<SquareRepo>
    internal val clickListener: RecyclerViewAdapter.ClickListener
    internal val image = HashMap<Int, Bitmap>()

    init {
        this.clickListener = clickListener
        data = ArrayList()
    }

    interface ClickListener {
        fun launchIntent(RepoName: String)
    }

    fun setData(data: List<SquareRepo>) {
        this.data.addAll(data)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val listItem = layoutInflater.inflate(layout.square_repo_recyclerview, parent, false)
        return RecyclerViewAdapter.ViewHolder(listItem)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.id_textView.text = data[position].id.toString()
        holder.name_textView.text = data[position].name
        holder.forkCount_textView.text = data[position].forksCount.toString()
        holder.watchers_textView.text = data[position].watchers.toString()
        holder.update_textView.text = data[position].updatedAt
        holder.size_textView.text = data[position].size.toString()
        holder.weblink_textView.text = data[position].htmlUrl

        holder.adminRadioButton.isChecked = data[position].permissions?.admin!!
        holder.pushRadioButton.isChecked = data[position].permissions?.push!!
        holder.pullRadioButton.isChecked = data[position].permissions?.pull!!

        Picasso.get().load(data[position].owner?.avatarUrl!!).into(holder.imageView);


    }


    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var id_textView: TextView
        var name_textView: TextView
        var forkCount_textView: TextView
        var watchers_textView: TextView
        var update_textView: TextView
        var size_textView: TextView
        var weblink_textView: TextView
        var adminRadioButton: RadioButton
        var pushRadioButton: RadioButton
        var pullRadioButton: RadioButton
        var imageView: ImageView
        var radiogroup: RadioGroup

        init {

            id_textView = itemView.findViewById(id.id_textView)
            name_textView = itemView.findViewById(id.name_textView)
            forkCount_textView = itemView.findViewById(id.forkCount_textView)
            watchers_textView = itemView.findViewById(id.watchers_textView)
            update_textView = itemView.findViewById(id.update_textView)
            size_textView = itemView.findViewById(id.size_textView)
            adminRadioButton = itemView.findViewById(id.adminRadioButton)
            pushRadioButton = itemView.findViewById(id.pushRadioButton)
            pullRadioButton = itemView.findViewById(id.pullRadioButton)
            weblink_textView = itemView.findViewById(id.weblink_textView)
            imageView = itemView.findViewById(id.imageView)
            radiogroup = itemView.findViewById(id.radiogroup)

        }
    }

}
