package com.mayuri.squarerepo.di.qualifier

import javax.inject.Qualifier


@Qualifier
annotation class ApplicationContext
