package com.mayuri.squarerepo.retrofit


import com.mayuri.squarerepo.pojo.SquareRepo

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url
import javax.inject.Inject


interface APIInterface {

    @get:GET("repos")
    val squareRepo: Call<List<SquareRepo>>

    companion object {

        /*@GET
    Call<SquareRepo> getSquareRepo(@Query("format") String format);*/

        val BASE_URL = "https://api.github.com/orgs/square/"
    }


    /* @GET("people/?")
    Call<StarWars> getPeople(@Query("format") String format);

    @GET
    Call<Film> getFilmData(@Url String url, @Query("format") String format);*/
}
