package com.mayuri.squarerepo

import android.app.Activity
import android.app.Application

import com.mayuri.squarerepo.di.component.ApplicationComponent
import com.mayuri.squarerepo.di.component.DaggerApplicationComponent
//import com.mayuri.squarerepo.di.component.DaggerApplicationComponent
import com.mayuri.squarerepo.di.module.ContextModule
import javax.inject.Inject


class MyApplication(applicationComponent: ApplicationComponent) : Application() {

    var applicationComponent: ApplicationComponent = applicationComponent
        internal set

    override fun onCreate() {
        super.onCreate()

      applicationComponent = DaggerApplicationComponent.builder().contextModule(ContextModule(this)).build()
        applicationComponent.injectApplication(this)

    }

    companion object {

        operator fun get(activity: Activity): MyApplication {
            return activity.application as MyApplication
        }
    }
}

