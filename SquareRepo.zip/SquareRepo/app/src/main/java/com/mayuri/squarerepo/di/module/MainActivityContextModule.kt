package com.mayuri.squarerepo.di.module

import android.content.Context


import com.mayuri.squarerepo.di.qualifier.ActivityContext
import com.mayuri.squarerepo.di.scope.ActivityScope
import com.mayuri.squarerepo.ui.MainActivity

import dagger.Module
import dagger.Provides


@Module
class MainActivityContextModule(private val mainActivity: MainActivity) {

    var context: Context

    init {
        context = mainActivity
    }

    @Provides
    @ActivityScope
    fun providesMainActivity(): MainActivity {
        return mainActivity
    }

    @Provides
    @ActivityScope
    @ActivityContext
    fun provideContext(): Context {
        return context
    }

}
