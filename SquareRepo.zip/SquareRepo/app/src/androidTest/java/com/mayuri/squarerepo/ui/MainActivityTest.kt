package com.mayuri.squarerepo.ui

import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.matcher.ViewMatchers
import androidx.test.rule.ActivityTestRule
import com.mayuri.squarerepo.R
import org.junit.Test

import org.junit.Assert.*
import org.junit.Rule

class MainActivityTest {

    @Rule
    var mainActivityActivityTestRule = ActivityTestRule(MainActivity::class.java)


    @Test
    fun recycleTest() {
        Expresso.onView(ViewMatchers.withId(R.id.recyclerview)).perform(RecyclerViewActions
                .actionOnItemAtPosition(0, ViewActions.click()))
    }
}